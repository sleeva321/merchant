export class Merchant
{
public merchant_id:number;
public uName:string;
 public pwd: string;
 
}
