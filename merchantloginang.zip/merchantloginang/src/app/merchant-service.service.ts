import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Merchant} from './merchant';

@Injectable({
  providedIn: 'root'
})
export class MerchantServiceService {

  url = 'http://localhost:9484/';

 constructor(private httpClient:HttpClient) { }
 public getMerchantByUsername(loginByUsername)
 {
 console.log(loginByUsername)
 return this.httpClient.get<Merchant>("http://localhost:9484//login/{username}/{password}" ,loginByUsername)
 }
}